#include <QApplication>
#include "appointmentform.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);     //create QApplication to control flow of the application
    AppointmentForm af;             //create our main form

    af.show();                      //make our main form visible

    return a.exec();                //Enters the main event loop and waits until exit() is called
}

#ifndef APPOINTMENTFORM_H
#define APPOINTMENTFORM_H

#include <QWidget>
#include <QLabel>
#include <QDateTimeEdit>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QComboBox>
#include <QTextEdit>
#include <QPushButton>
#include <QGridLayout>

class AppointmentForm : public QWidget
{
    Q_OBJECT
public:
    explicit AppointmentForm(QWidget *parent = 0);


    void createUI();                    //put creation of the widgets and signal activation in one function
    void saveToDatabase();              //function to save to the file
    void createDatabase();              //function to create the database

private:
    //declare all the widgets and layouts as global to the class so that we can access the from anywhere within the class
    QPushButton *btnSave, *btnDiscard;
    QTextEdit *txtSummary;
    QDateTimeEdit *dteStart;
    QDateTimeEdit *dteFinish;
    QComboBox *cmbLocation;

    QVBoxLayout *layMain;               //layout of the whole form
    QHBoxLayout *layButtons;            //layout for save and cancel button
    QGridLayout *layInput;

    void saveToFile();                  //function to save to a file

signals:

public slots:
    //slots called when buttons are clicked
    void saveData();
    void discardData();
};

#endif // APPOINTMENTFORM_H

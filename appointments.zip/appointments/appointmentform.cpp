#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include "appointmentform.h"

AppointmentForm::AppointmentForm(QWidget *parent) :
    QWidget(parent)
{
    createDatabase();
    createUI();
}

void AppointmentForm::createUI(){
    setWindowTitle(tr("Appointments"));

    //initialize the widgets to be used for input
    btnSave = new QPushButton("Save");
    btnDiscard = new QPushButton("Discard");
    txtSummary = new QTextEdit();
    dteStart = new QDateTimeEdit();
    dteFinish = new QDateTimeEdit();
    cmbLocation = new QComboBox();

    //make sure th date is displayed in the correct format
    dteStart->setDisplayFormat("yyyy-MM-dd hh:mm AP");
    dteFinish->setDisplayFormat("yyyy-MM-dd hh:mm AP");

    //initialize the layouts
    layMain = new QVBoxLayout();
    layButtons = new QHBoxLayout();
    layInput = new QGridLayout();

    //set the dates to todays date for both datetime edits
    dteStart->setDateTime(QDateTime::currentDateTime());
    dteFinish->setDateTime(QDateTime::currentDateTime());

    //layout components to the main form
    layMain->addLayout(layInput);
    layMain->addWidget(new QLabel("Summary:"));
    layMain->addWidget(txtSummary);
    layMain->addLayout(layButtons);

    layButtons->addStretch();       //make sure the buttons are centered to the right
    layButtons->addWidget(btnSave);
    layButtons->addWidget(btnDiscard);
    layButtons->addStretch();       //make sure the buttons are centered to the left

    //add the widgets to the top layout
    layInput->addWidget(new QLabel("Start:"), 0,0);
    layInput->addWidget(dteStart,0,1);
    layInput->addWidget(new QLabel("Finish:"));
    layInput->addWidget(dteFinish);
    layInput->addWidget(new QLabel("Location:"));
    layInput->addWidget(cmbLocation);

    //add details to the combobox
    cmbLocation->addItem("Active Learning Lab");
    cmbLocation->addItem("Fire point");
    cmbLocation->addItem("Main Laboratory");

    //apply mainLayout to the parent/main widget
    setLayout(layMain);

    //connect button clicks to specific actions defined in their own functions
    connect(btnDiscard, SIGNAL(clicked()),this, SLOT(discardData()));
    connect(btnSave, SIGNAL(clicked()),this, SLOT(saveData()));
}


void AppointmentForm::saveData(){
    saveToFile();                   //save th appointment to a file
    saveToDatabase();               //save th appointment to an SQLite Database
}

void AppointmentForm::discardData(){
    txtSummary->clear();
    dteStart->setDateTime(QDateTime::currentDateTime());                //first set the time to current date time
    int minutes = dteStart->time().minute();
    int hour = dteStart->time().hour();
    QTime *time;

    //compare the minute inorder to round of correctly
    if(minutes >= 30){
        time = new QTime(hour+1, 0);
    }else{
        time = new QTime(hour, 0);
    }
    dteStart->setTime(*time);                                           //the set time to rounded time
    dteFinish->setDateTime(dteStart->dateTime().addSecs(3600));
    cmbLocation->setCurrentIndex(cmbLocation->findText("Active Learning Lab"));
}

void AppointmentForm::saveToFile(){
    QFile file("appointments.data");
    if(!file.open(QFile::WriteOnly)){
        qDebug()<<"Could not open File for writing";
        return;
    }

    //write the data using a QTextStream
    QTextStream out(&file);
    out << "Start: " <<dteStart->dateTime().toString("yyyy-MM-dd hh:mm AP");
    out << "\nFinish: " <<dteFinish->dateTime().toString("yyyy-MM-dd hh:mm AP");
    out << "\nLocation: " <<cmbLocation->currentText();
    out << "\nSummary: " <<txtSummary->toPlainText();

}

void AppointmentForm::saveToDatabase(){
    //create a query to insert the data to the database
    QSqlQuery q;
    q.prepare("INSERT INTO appointments(start, finish, location, summary) VALUES(?,?,?,?);");
    //bind user interface values from the User interface to the columns in the database
    q.addBindValue(dteStart->dateTime());
    q.addBindValue(dteFinish->dateTime());
    q.addBindValue(cmbLocation->currentText());
    q.addBindValue(txtSummary->toPlainText());

    //execute the query
    if(!q.exec()){
        qDebug() << "Could not add appointment to the database";
        return;
    }else{
        discardData();          //clear the contents if save was successful
    }
}

void AppointmentForm::createDatabase(){
    //create a database connection with SQLITE driver and open it
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("AppointmentsDb");
    if(!db.open()){
        qDebug() << "Could not create the database";
        return;
    }

    //execute a query to create a table where we will store the appointments
    //if it fails the we assume it had already been created before
    QSqlQuery q("CREATE TABLE appointments(start DATETIME, finish DATETIME, location TEXT, summary TEXT);");
    if(!q.exec()){
        qDebug() << "Could not create the table. Probably the database already exists"<<q.lastError().text();
        return;
    }
}
